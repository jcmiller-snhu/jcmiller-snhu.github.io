package com.example.inventoryapp;

/*
 * Author: Jonathon Miller
 * Date: October 4, 2026
 * Course: CS-499
 * Purpose: Represents an inventory item so inventory records can be
 * stored, searched, filtered, and sorted in memory.
 */

public class InventoryItem {

    private final int id;
    private final String itemName;
    private final int quantity;
    private final String category;
    private final int lowStockThreshold;
    private final String lastModifiedBy;

    public InventoryItem(
            int id,
            String itemName,
            int quantity,
            String category,
            int lowStockThreshold,
            String lastModifiedBy) {

        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.category = category;
        this.lowStockThreshold =
                lowStockThreshold;
        this.lastModifiedBy =
                lastModifiedBy;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getCategory() {
        return category;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }
}