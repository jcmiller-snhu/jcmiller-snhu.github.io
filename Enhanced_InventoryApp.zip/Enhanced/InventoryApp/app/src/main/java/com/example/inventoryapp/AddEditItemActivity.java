package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/*
 * Author: Jonathon Miller
 * Date: September 27, 2026
 * Course: CS-499
 * Purpose: Handles adding and editing inventory items and validates input before saving.
 */

public class AddEditItemActivity extends AppCompatActivity {

    private EditText itemNameText;
    private EditText quantityText;
    private EditText categoryText;

    private DatabaseHelper databaseHelper;

    private int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_add_edit_item
        );

        itemNameText =
                findViewById(R.id.itemNameText);

        quantityText =
                findViewById(R.id.quantityText);

        categoryText =
                findViewById(R.id.categoryText);

        Button saveButton =
                findViewById(R.id.saveButton);

        Button cancelButton =
                findViewById(R.id.cancelButton);

        databaseHelper =
                new DatabaseHelper(this);

        itemId =
                getIntent().getIntExtra(
                        "id",
                        -1
                );

        if (itemId != -1) {

            String itemName =
                    getIntent()
                            .getStringExtra("itemName");

            int quantity =
                    getIntent()
                            .getIntExtra(
                                    "quantity",
                                    0
                            );

            String category =
                    getIntent()
                            .getStringExtra("category");

            itemNameText.setText(itemName);

            quantityText.setText(
                    String.valueOf(quantity)
            );

            if (category != null) {
                categoryText.setText(category);
            }
        }

        saveButton.setOnClickListener(view -> {

            String itemName =
                    itemNameText
                            .getText()
                            .toString()
                            .trim();

            String quantityString =
                    quantityText
                            .getText()
                            .toString()
                            .trim();

            String category =
                    categoryText
                            .getText()
                            .toString()
                            .trim();

            if (category.length() == 0) {
                category = "Uncategorized";
            }

            if (itemName.length() == 0 ||
                    quantityString.length() == 0) {

                Toast.makeText(
                        this,
                        "Enter an item name and quantity",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int quantity;

            try {

                quantity =
                        Integer.parseInt(
                                quantityString
                        );

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Quantity must be a valid number",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (quantity < 0) {

                Toast.makeText(
                        this,
                        "Quantity cannot be negative",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int userId =
                    getSharedPreferences(
                            "session",
                            MODE_PRIVATE
                    )
                            .getInt(
                                    "userId",
                                    -1
                            );

            if (userId == -1) {

                Toast.makeText(
                        this,
                        "Unable to identify logged-in user",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            SharedPreferences preferences =
                    getSharedPreferences(
                            "settings",
                            MODE_PRIVATE
                    );

            int lowStockThreshold =
                    preferences.getInt(
                            "lowStockThreshold",
                            0
                    );

            boolean saveSuccessful;

            if (itemId == -1) {

                saveSuccessful =
                        databaseHelper.addItem(
                                itemName,
                                quantity,
                                category,
                                lowStockThreshold,
                                userId
                        );

            } else {

                saveSuccessful =
                        databaseHelper.updateItem(
                                itemId,
                                itemName,
                                quantity,
                                category,
                                lowStockThreshold,
                                userId
                        );
            }

            if (saveSuccessful) {

                if (itemId == -1) {

                    Toast.makeText(
                            this,
                            "Item added",
                            Toast.LENGTH_SHORT
                    ).show();

                } else {

                    Toast.makeText(
                            this,
                            "Item updated",
                            Toast.LENGTH_SHORT
                    ).show();
                }

                if (quantity <= lowStockThreshold) {
                    sendInventoryAlert(itemName);
                }

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Unable to save item",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        cancelButton.setOnClickListener(
                view -> finish()
        );
    }

    private void sendInventoryAlert(
            String itemName) {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            SharedPreferences preferences =
                    getSharedPreferences(
                            "settings",
                            MODE_PRIVATE
                    );

            String phoneNumber =
                    preferences.getString(
                            "phoneNumber",
                            ""
                    );

            if (phoneNumber.length() > 0) {

                SmsManager smsManager =
                        SmsManager.getDefault();

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "Inventory alert: " +
                                itemName +
                                " is low on stock.",
                        null,
                        null
                );
            }
        }
    }
}