package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * Author: Jonathon Miller
 * Date: October 11, 2026
 * Course: CS-499
 * Purpose: Manages the SQLite database, including users, inventory records,
 * database upgrades, and database-related security improvements.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "password TEXT)"
        );

        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT, " +
                        "quantity INTEGER, " +
                        "category TEXT, " +
                        "low_stock_threshold INTEGER DEFAULT 0, " +
                        "last_modified_by INTEGER)"
        );

        db.execSQL(
                "CREATE INDEX idx_inventory_name ON inventory(item_name)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Upgrade from version 1 to version 2 without deleting existing data.
        if (oldVersion < 2) {

            db.execSQL(
                    "ALTER TABLE inventory ADD COLUMN category TEXT"
            );

            db.execSQL(
                    "ALTER TABLE inventory ADD COLUMN low_stock_threshold INTEGER DEFAULT 0"
            );

            db.execSQL(
                    "ALTER TABLE inventory ADD COLUMN last_modified_by INTEGER"
            );

            db.execSQL(
                    "CREATE INDEX IF NOT EXISTS idx_inventory_name ON inventory(item_name)"
            );

            // Replace existing plaintext passwords with password hashes.
            Cursor userCursor = db.rawQuery(
                    "SELECT id, password FROM users",
                    null
            );

            while (userCursor.moveToNext()) {

                int userId = userCursor.getInt(0);
                String oldPassword = userCursor.getString(1);

                String hashedPassword =
                        PasswordHelper.hashPassword(oldPassword);

                if (hashedPassword != null) {

                    ContentValues values = new ContentValues();
                    values.put("password", hashedPassword);

                    db.update(
                            "users",
                            values,
                            "id=?",
                            new String[]{String.valueOf(userId)}
                    );
                }
            }

            userCursor.close();
        }
    }

    public boolean addUser(String username, String password) {

        SQLiteDatabase db = getWritableDatabase();

        String hashedPassword =
                PasswordHelper.hashPassword(password);

        if (hashedPassword == null) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", hashedPassword);

        long result =
                db.insert("users", null, values);

        return result != -1;
    }

    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT password FROM users WHERE username=?",
                new String[]{username}
        );

        boolean passwordMatches = false;

        if (cursor.moveToFirst()) {

            String storedPassword =
                    cursor.getString(0);

            passwordMatches =
                    PasswordHelper.verifyPassword(
                            password,
                            storedPassword
                    );
        }

        cursor.close();

        return passwordMatches;
    }

    public int getUserId(String username) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=?",
                new String[]{username}
        );

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        cursor.close();

        return userId;
    }

    public boolean addItem(
            String itemName,
            int quantity,
            String category,
            int lowStockThreshold,
            int userId) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("category", category);
        values.put("low_stock_threshold", lowStockThreshold);
        values.put("last_modified_by", userId);

        long result =
                db.insert("inventory", null, values);

        return result != -1;
    }

    public Cursor getAllItems() {

        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT inventory.id, " +
                        "inventory.item_name, " +
                        "inventory.quantity, " +
                        "inventory.category, " +
                        "inventory.low_stock_threshold, " +
                        "users.username " +
                        "FROM inventory " +
                        "LEFT JOIN users " +
                        "ON inventory.last_modified_by = users.id",
                null
        );
    }

    public boolean updateItem(
            int id,
            String itemName,
            int quantity,
            String category,
            int lowStockThreshold,
            int userId) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("category", category);
        values.put("low_stock_threshold", lowStockThreshold);
        values.put("last_modified_by", userId);

        int result = db.update(
                "inventory",
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    public boolean deleteItem(int id) {

        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                "inventory",
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}