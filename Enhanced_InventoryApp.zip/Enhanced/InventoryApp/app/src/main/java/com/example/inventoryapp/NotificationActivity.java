package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/*
 * Author: Jonathon Miller
 * Date: September 27, 2026
 * Course: CS-499
 * Purpose: Stores SMS notification settings and allows the user to set a low-stock threshold.
 */

public class NotificationActivity extends AppCompatActivity {

    private EditText phoneNumberText;
    private EditText lowStockThresholdText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        phoneNumberText = findViewById(R.id.phoneNumberText);
        lowStockThresholdText = findViewById(R.id.lowStockThresholdText);
        Button enableNotificationsButton =
                findViewById(R.id.enableNotificationsButton);

        SharedPreferences preferences =
                getSharedPreferences("settings", MODE_PRIVATE);

        phoneNumberText.setText(
                preferences.getString("phoneNumber", "")
        );

        lowStockThresholdText.setText(
                String.valueOf(preferences.getInt("lowStockThreshold", 0))
        );

        enableNotificationsButton.setOnClickListener(view -> {

            String phoneNumber =
                    phoneNumberText.getText().toString().trim();

            String thresholdString =
                    lowStockThresholdText.getText().toString().trim();

            if (phoneNumber.length() == 0) {
                Toast.makeText(
                        this,
                        "Enter a phone number",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (thresholdString.length() == 0) {
                Toast.makeText(
                        this,
                        "Enter a low-stock threshold",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            int lowStockThreshold;

            try {
                lowStockThreshold = Integer.parseInt(thresholdString);
            } catch (NumberFormatException e) {
                Toast.makeText(
                        this,
                        "Threshold must be a valid number",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (lowStockThreshold < 0) {
                Toast.makeText(
                        this,
                        "Threshold cannot be negative",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            preferences.edit()
                    .putString("phoneNumber", phoneNumber)
                    .putInt("lowStockThreshold", lowStockThreshold)
                    .apply();

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        1
                );

            } else {
                Toast.makeText(
                        this,
                        "SMS notifications enabled",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}