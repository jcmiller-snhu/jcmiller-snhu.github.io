package com.example.inventoryapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/*
 * Author: Jonathon Miller
 * Date: October 4, 2026
 * Course: CS-499
 * Purpose: Displays inventory items and uses an ArrayList with searching,
 * filtering, and sorting to organize inventory records.
 */

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;

    private EditText searchInventoryText;
    private CheckBox lowStockOnlyCheckBox;

    private final ArrayList<InventoryItem> inventoryItems =
            new ArrayList<>();

    private String searchQuery = "";
    private String sortMode = "none";
    private boolean showLowStockOnly = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_inventory
        );

        databaseHelper =
                new DatabaseHelper(this);

        inventoryTable =
                findViewById(
                        R.id.inventoryTable
                );

        searchInventoryText =
                findViewById(
                        R.id.searchInventoryText
                );

        lowStockOnlyCheckBox =
                findViewById(
                        R.id.lowStockOnlyCheckBox
                );

        Button searchButton =
                findViewById(
                        R.id.searchButton
                );

        Button sortNameButton =
                findViewById(
                        R.id.sortNameButton
                );

        Button sortQuantityButton =
                findViewById(
                        R.id.sortQuantityButton
                );

        Button addItemButton =
                findViewById(
                        R.id.addItemButton
                );

        Button notificationSettingsButton =
                findViewById(
                        R.id.notificationSettingsButton
                );

        addItemButton.setOnClickListener(view -> {

            Intent intent =
                    new Intent(
                            this,
                            AddEditItemActivity.class
                    );

            startActivity(intent);
        });

        notificationSettingsButton
                .setOnClickListener(view -> {

                    Intent intent =
                            new Intent(
                                    this,
                                    NotificationActivity.class
                            );

                    startActivity(intent);
                });

        searchButton.setOnClickListener(view -> {

            searchQuery =
                    searchInventoryText
                            .getText()
                            .toString()
                            .trim();

            displayItems();
        });

        sortNameButton.setOnClickListener(view -> {

            sortMode = "name";
            displayItems();
        });

        sortQuantityButton.setOnClickListener(view -> {

            sortMode = "quantity";
            displayItems();
        });

        lowStockOnlyCheckBox
                .setOnCheckedChangeListener(
                        (buttonView, isChecked) -> {

                            showLowStockOnly =
                                    isChecked;

                            displayItems();
                        });

        displayItems();
    }

    @Override
    protected void onResume() {
        super.onResume();

        displayItems();
    }

    private void displayItems() {

        while (inventoryTable.getChildCount() > 1) {

            inventoryTable.removeViewAt(1);
        }

        Cursor cursor =
                databaseHelper.getAllItems();

        // Load database records into an ArrayList of InventoryItem objects.
        inventoryItems.clear();

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(0);

            String itemName =
                    cursor.getString(1);

            int quantity =
                    cursor.getInt(2);

            String category =
                    cursor.getString(3);

            if (category == null ||
                    category.length() == 0) {

                category =
                        "Uncategorized";
            }

            int lowStockThreshold =
                    cursor.getInt(4);

            String lastModifiedBy =
                    cursor.getString(5);

            if (lastModifiedBy == null) {

                lastModifiedBy =
                        "Unknown";
            }

            inventoryItems.add(
                    new InventoryItem(
                            id,
                            itemName,
                            quantity,
                            category,
                            lowStockThreshold,
                            lastModifiedBy
                    )
            );
        }

        cursor.close();

        // Search and filter the inventory collection.
        ArrayList<InventoryItem> displayedItems =
                new ArrayList<>();

        for (InventoryItem item :
                inventoryItems) {

            boolean matchesSearch =
                    searchQuery.isEmpty()
                            || item.getItemName()
                            .toLowerCase()
                            .contains(
                                    searchQuery
                                            .toLowerCase()
                            );

            boolean matchesLowStock =
                    !showLowStockOnly
                            || item.getQuantity()
                            <= item.getLowStockThreshold();

            if (matchesSearch &&
                    matchesLowStock) {

                displayedItems.add(item);
            }
        }

        // Sort the filtered collection by name or quantity.
        if (sortMode.equals("name")) {

            Collections.sort(
                    displayedItems,
                    Comparator.comparing(
                            InventoryItem::getItemName,
                            String.CASE_INSENSITIVE_ORDER
                    )
            );

        } else if (sortMode.equals("quantity")) {

            Collections.sort(
                    displayedItems,
                    Comparator.comparingInt(
                            InventoryItem::getQuantity
                    )
            );
        }

        for (InventoryItem item :
                displayedItems) {

            int id =
                    item.getId();

            String itemName =
                    item.getItemName();

            int quantity =
                    item.getQuantity();

            String category =
                    item.getCategory();

            int lowStockThreshold =
                    item.getLowStockThreshold();

            String lastModifiedBy =
                    item.getLastModifiedBy();

            TableRow row =
                    new TableRow(this);

            TextView itemText =
                    new TextView(this);

            itemText.setText(
                    itemName +
                            "\nCategory: " +
                            category +
                            "\nModified by: " +
                            lastModifiedBy
            );

            itemText.setPadding(
                    8,
                    8,
                    8,
                    8
            );

            TextView quantityText =
                    new TextView(this);

            if (quantity <= lowStockThreshold) {

                quantityText.setText(
                        quantity + " - Low"
                );

            } else {

                quantityText.setText(
                        String.valueOf(quantity)
                );
            }

            quantityText.setPadding(
                    8,
                    8,
                    8,
                    8
            );

            LinearLayout actions =
                    new LinearLayout(this);

            Button editButton =
                    new Button(this);

            editButton.setText("Edit");
            editButton.setMinWidth(0);

            Button deleteButton =
                    new Button(this);

            deleteButton.setText("Delete");
            deleteButton.setMinWidth(0);

            editButton.setOnClickListener(view -> {

                Intent intent =
                        new Intent(
                                this,
                                AddEditItemActivity.class
                        );

                intent.putExtra(
                        "id",
                        id
                );

                intent.putExtra(
                        "itemName",
                        itemName
                );

                intent.putExtra(
                        "quantity",
                        quantity
                );

                intent.putExtra(
                        "category",
                        category
                );

                startActivity(intent);
            });

            deleteButton.setOnClickListener(view -> {

                new AlertDialog.Builder(this)
                        .setTitle("Delete Item")
                        .setMessage(
                                "Are you sure you want to delete " +
                                        itemName +
                                        "?"
                        )
                        .setPositiveButton(
                                "Delete",
                                (dialog, which) -> {

                                    boolean deleted =
                                            databaseHelper
                                                    .deleteItem(id);

                                    if (deleted) {

                                        Toast.makeText(
                                                this,
                                                "Item deleted",
                                                Toast.LENGTH_SHORT
                                        ).show();

                                        displayItems();

                                    } else {

                                        Toast.makeText(
                                                this,
                                                "Unable to delete item",
                                                Toast.LENGTH_SHORT
                                        ).show();
                                    }
                                })
                        .setNegativeButton(
                                "Cancel",
                                null
                        )
                        .show();
            });

            actions.addView(editButton);
            actions.addView(deleteButton);

            row.addView(itemText);
            row.addView(quantityText);
            row.addView(actions);

            inventoryTable.addView(row);
        }
    }
}