package com.example.inventoryapp;

import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/*
 * Author: Jonathon Miller
 * Date: October 11, 2026
 * Course: CS-499
 * Purpose: Creates and verifies password hashes so plaintext passwords
 * are not stored directly in the database.
 */

public class PasswordHelper {

    private static final int ITERATIONS = 10000;
    private static final int KEY_LENGTH = 256;

    public static String hashPassword(String password) {

        try {

            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            PBEKeySpec spec =
                    new PBEKeySpec(
                            password.toCharArray(),
                            salt,
                            ITERATIONS,
                            KEY_LENGTH
                    );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            byte[] hash =
                    factory.generateSecret(spec).getEncoded();

            String saltString =
                    Base64.encodeToString(
                            salt,
                            Base64.NO_WRAP
                    );

            String hashString =
                    Base64.encodeToString(
                            hash,
                            Base64.NO_WRAP
                    );

            return saltString + ":" + hashString;

        } catch (Exception e) {

            return null;
        }
    }

    public static boolean verifyPassword(
            String password,
            String storedPassword) {

        try {

            String[] parts =
                    storedPassword.split(":");

            if (parts.length != 2) {
                return false;
            }

            byte[] salt =
                    Base64.decode(
                            parts[0],
                            Base64.NO_WRAP
                    );

            byte[] storedHash =
                    Base64.decode(
                            parts[1],
                            Base64.NO_WRAP
                    );

            PBEKeySpec spec =
                    new PBEKeySpec(
                            password.toCharArray(),
                            salt,
                            ITERATIONS,
                            KEY_LENGTH
                    );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            byte[] enteredHash =
                    factory.generateSecret(spec).getEncoded();

            return MessageDigest.isEqual(
                    enteredHash,
                    storedHash
            );

        } catch (Exception e) {

            return false;
        }
    }
}