package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);
        inventoryTable = findViewById(R.id.inventoryTable);

        Button addItemButton = findViewById(R.id.addItemButton);
        Button notificationSettingsButton =
                findViewById(R.id.notificationSettingsButton);

        addItemButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, AddEditItemActivity.class);
            startActivity(intent);
        });

        notificationSettingsButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, NotificationActivity.class);
            startActivity(intent);
        });

        displayItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayItems();
    }

    private void displayItems() {

        while (inventoryTable.getChildCount() > 1) {
            inventoryTable.removeViewAt(1);
        }

        Cursor cursor = databaseHelper.getAllItems();

        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int quantity = cursor.getInt(2);

            TableRow row = new TableRow(this);

            TextView itemText = new TextView(this);
            itemText.setText(itemName);
            itemText.setPadding(8, 8, 8, 8);

            TextView quantityText = new TextView(this);
            quantityText.setText(String.valueOf(quantity));
            quantityText.setPadding(8, 8, 8, 8);

            LinearLayout actions = new LinearLayout(this);

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setMinWidth(0);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setMinWidth(0);

            editButton.setOnClickListener(view -> {
                Intent intent = new Intent(this, AddEditItemActivity.class);
                intent.putExtra("id", id);
                intent.putExtra("itemName", itemName);
                intent.putExtra("quantity", quantity);
                startActivity(intent);
            });

            deleteButton.setOnClickListener(view -> {
                databaseHelper.deleteItem(id);
                displayItems();
            });

            actions.addView(editButton);
            actions.addView(deleteButton);

            row.addView(itemText);
            row.addView(quantityText);
            row.addView(actions);

            inventoryTable.addView(row);
        }

        cursor.close();
    }
}