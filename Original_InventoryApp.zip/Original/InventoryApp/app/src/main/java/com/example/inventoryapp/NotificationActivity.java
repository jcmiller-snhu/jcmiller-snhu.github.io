package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private EditText phoneNumberText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        phoneNumberText = findViewById(R.id.phoneNumberText);
        Button enableNotificationsButton =
                findViewById(R.id.enableNotificationsButton);

        SharedPreferences preferences =
                getSharedPreferences("settings", MODE_PRIVATE);

        phoneNumberText.setText(
                preferences.getString("phoneNumber", "")
        );

        enableNotificationsButton.setOnClickListener(view -> {

            String phoneNumber =
                    phoneNumberText.getText().toString();

            if (phoneNumber.length() == 0) {
                Toast.makeText(
                        this,
                        "Enter a phone number",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            preferences.edit()
                    .putString("phoneNumber", phoneNumber)
                    .apply();

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        1
                );

            } else {
                Toast.makeText(
                        this,
                        "SMS notifications enabled",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}