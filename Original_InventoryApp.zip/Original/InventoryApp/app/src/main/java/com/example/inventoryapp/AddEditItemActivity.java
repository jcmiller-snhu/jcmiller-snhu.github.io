package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class AddEditItemActivity extends AppCompatActivity {

    private EditText itemNameText;
    private EditText quantityText;
    private DatabaseHelper databaseHelper;

    private int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        itemNameText = findViewById(R.id.itemNameText);
        quantityText = findViewById(R.id.quantityText);

        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        databaseHelper = new DatabaseHelper(this);

        itemId = getIntent().getIntExtra("id", -1);

        if (itemId != -1) {
            String itemName = getIntent().getStringExtra("itemName");
            int quantity = getIntent().getIntExtra("quantity", 0);

            itemNameText.setText(itemName);
            quantityText.setText(String.valueOf(quantity));
        }

        saveButton.setOnClickListener(view -> {

            String itemName = itemNameText.getText().toString();
            String quantityString = quantityText.getText().toString();

            if (itemName.length() == 0 || quantityString.length() == 0) {
                Toast.makeText(
                        this,
                        "Enter an item name and quantity",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            int quantity = Integer.parseInt(quantityString);

            if (quantity == 0) {
                sendInventoryAlert(itemName);
            }

            if (itemId == -1) {

                if (databaseHelper.addItem(itemName, quantity)) {
                    Toast.makeText(
                            this,
                            "Item added",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                }

            } else {

                if (databaseHelper.updateItem(itemId, itemName, quantity)) {
                    Toast.makeText(
                            this,
                            "Item updated",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                }
            }
        });

        cancelButton.setOnClickListener(view -> finish());
    }

    private void sendInventoryAlert(String itemName) {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            SharedPreferences preferences =
                    getSharedPreferences("settings", MODE_PRIVATE);

            String phoneNumber =
                    preferences.getString("phoneNumber", "");

            if (phoneNumber.length() > 0) {

                SmsManager smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "Inventory alert: " + itemName + " has reached zero.",
                        null,
                        null
                );
            }
        }
    }
}