package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameText;
    private EditText passwordText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(view -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();

            if (username.length() == 0 || password.length() == 0) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.checkUser(username, password)) {
                Intent intent = new Intent(this, InventoryActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        createAccountButton.setOnClickListener(view -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();

            if (username.length() == 0 || password.length() == 0) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.addUser(username, password)) {
                Toast.makeText(this,
                        "Account created",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Username already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}